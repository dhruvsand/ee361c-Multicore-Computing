package q6.Tournament;

public class TournamentLock implements q6.Tournament.Lock {
    public TournamentLock(int numThreads){
        // your implementation goes here.
    }

    @Override
    public void lock(int pid) {

    }

    @Override
    public void unlock(int pid) {

    }
}
