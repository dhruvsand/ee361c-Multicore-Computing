package q6.Tournament;

public class PIncrement implements Runnable{
    public static int parallelIncrement(int c, int numThreads){
        // your implementation goes here
        return 0;
    }

    @Override
    public void run() {

    }
}
